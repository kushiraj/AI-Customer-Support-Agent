"""RecallDesk - the fix one customer finds becomes every customer's fix.

Memory design (this is the core of the project):
  * One Hindsight bank PER CUSTOMER  -> their tickets, environment, preferences, mood.
  * One shared PLAYBOOK bank         -> which fixes actually worked, across ALL customers, so a
                                         resolution found for account A is recalled for account B
                                         without anyone writing a runbook.
  * retain() after every turn, recall() before every answer, reflect() for account briefs.

v3.0.0 adds five upgrades on top of the original chatbot:
  1. Conversation History  - chats are saved to SQLite; customers/agents can list & resume them.
  2. Ticket Management     - tickets are auto-opened for issues and tracked (status + priority).
  3. Human Handoff         - unresolved / explicitly-requested issues escalate to a human queue.
  4. Better Memory         - PII is redacted before anything is retained, and near-duplicate
                             memories are skipped so the bank doesn't fill up with restatements.
  5. Testing & Evaluation  - built-in /v1/eval/* self-checks for isolation & recall round-trips,
                             plus an offline pytest suite in tests/ and a scripted eval.py.
"""
import os, re, time, uuid, difflib, hashlib, secrets, sqlite3, logging, asyncio
from collections import defaultdict, deque
from contextlib import contextmanager, asynccontextmanager
from datetime import datetime, timezone
from fastapi import FastAPI, Depends, Header, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from openai import AsyncOpenAI
from hindsight_client import Hindsight

HS_URL = os.getenv("HINDSIGHT_URL", "http://localhost:8888")
HS_KEY = os.getenv("HINDSIGHT_API_KEY") or None
LLM_MODELS = [m.strip() for m in os.getenv("LLM_MODELS", "openai/gpt-oss-120b,qwen/qwen3-32b").split(",")]
ADMIN_KEY = os.getenv("ADMIN_KEY", "")
COMPANY = os.getenv("COMPANY_NAME", "Northstar Cloud")
RATE_LIMIT = int(os.getenv("RATE_LIMIT_PER_MIN", "30"))
DB_PATH = os.getenv("DB_PATH", "recalldesk.db")
DEDUPE_THRESHOLD = float(os.getenv("DEDUPE_THRESHOLD", "0.82"))   # upgrade 4
FAIL_STREAK_ESCALATE = int(os.getenv("FAIL_STREAK_ESCALATE", "2"))  # upgrade 3
CID_RE = r"^[A-Za-z0-9_.-]{1,80}$"
ID_RE = r"^[A-Za-z0-9_.-]{1,80}$"
PLAYBOOK = "recalldesk-playbook"

STATUSES = ("open", "pending_customer", "escalated", "resolved", "closed")
PRIORITIES = ("low", "medium", "high", "urgent")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("recalldesk")
hs = Hindsight(base_url=HS_URL, api_key=HS_KEY, timeout=60.0)
llm = AsyncOpenAI(api_key=os.getenv("LLM_API_KEY", "missing"),
                  base_url=os.getenv("LLM_BASE_URL", "https://api.groq.com/openai/v1"))

# ---------- SQLite store: api keys, conversations, messages, tickets ----------
@contextmanager
def db():
    con = sqlite3.connect(DB_PATH, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    try:
        yield con
        con.commit()
    finally:
        con.close()

def init_db():
    with db() as c:
        c.execute("CREATE TABLE IF NOT EXISTS api_keys(id INTEGER PRIMARY KEY, name TEXT, hash TEXT UNIQUE, created REAL)")
        # ---- upgrade 1: conversation history ----
        c.execute("""CREATE TABLE IF NOT EXISTS conversations(
            id TEXT PRIMARY KEY, customer_id TEXT NOT NULL, title TEXT,
            created REAL, updated REAL, fail_streak INTEGER DEFAULT 0)""")
        c.execute("""CREATE TABLE IF NOT EXISTS messages(
            id INTEGER PRIMARY KEY AUTOINCREMENT, conversation_id TEXT NOT NULL,
            role TEXT NOT NULL, content TEXT NOT NULL, ts REAL)""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conversation_id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_conv_cust ON conversations(customer_id)")
        # ---- upgrade 2 & 3: tickets + human handoff ----
        c.execute("""CREATE TABLE IF NOT EXISTS tickets(
            id TEXT PRIMARY KEY, customer_id TEXT NOT NULL, conversation_id TEXT,
            subject TEXT, status TEXT DEFAULT 'open', priority TEXT DEFAULT 'medium',
            assigned_to TEXT, resolution TEXT, created REAL, updated REAL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS ticket_events(
            id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id TEXT NOT NULL,
            event TEXT, note TEXT, ts REAL)""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_ticket_cust ON tickets(customer_id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_ticket_conv ON tickets(conversation_id)")

init_db()
hits: dict[int, deque] = defaultdict(deque)

def auth(x_api_key: str = Header(None)) -> int:
    if not x_api_key:
        raise HTTPException(401, "Missing X-API-Key")
    with db() as c:
        row = c.execute("SELECT id FROM api_keys WHERE hash=?", (hashlib.sha256(x_api_key.encode()).hexdigest(),)).fetchone()
    if not row:
        raise HTTPException(401, "Invalid API key")
    q, now = hits[row["id"]], time.time()
    while q and q[0] < now - 60:
        q.popleft()
    if len(q) >= RATE_LIMIT:
        raise HTTPException(429, "Rate limit exceeded")
    q.append(now)
    return row["id"]

def admin(x_admin_key: str = Header(None)):
    if not ADMIN_KEY or not secrets.compare_digest(x_admin_key or "", ADMIN_KEY):
        raise HTTPException(403, "Forbidden")

# ---------- Hindsight helpers ----------
def cbank(cid: str) -> str:
    return f"cust-{cid}"

_ready: set[str] = set()

async def ensure_bank(bank_id: str, name: str, mission: str):
    if bank_id in _ready:
        return
    try:
        await hs.acreate_bank(bank_id=bank_id, name=name, mission=mission)
    except Exception as e:  # already exists is fine
        log.info("create_bank(%s): %s", bank_id, e)
    _ready.add(bank_id)

CUSTOMER_MISSION = (f"I am the memory of a {COMPANY} support agent for ONE customer account. Track their people, "
    "tech environment, every ticket and its resolution, communication preferences, and frustration level.")
PLAYBOOK_MISSION = (f"I am {COMPANY}'s support playbook. Track which troubleshooting steps resolved which "
    "kinds of issues and which did not, so future answers use what has actually worked.")

async def recall_safe(bank_id: str, query: str, max_tokens: int, types=None) -> list[dict]:
    try:
        kw = {"types": types} if types else {}
        res = await hs.arecall(bank_id=bank_id, query=query, max_tokens=max_tokens, budget="mid", **kw)
        return [{"type": getattr(r, "type", "memory"), "text": r.text} for r in res.results]
    except Exception as e:
        log.warning("recall failed for %s: %s", bank_id, e)
        return []

# ---------- upgrade 4: memory hygiene (PII redaction + de-duplication) ----------
_PII_PATTERNS = [
    (re.compile(r"[\w.+-]+@[\w-]+\.[A-Za-z]{2,}"), "[EMAIL]"),
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "[SSN]"),
    (re.compile(r"\b(?:\d[ -]*?){13,16}\b"), "[CARD]"),
    (re.compile(r"(?<!\d)(\+?\d{1,2}[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}(?!\d)"), "[PHONE]"),
]

def redact_pii(text: str) -> str:
    """Strip emails, phone numbers, card-like and SSN-like numbers before anything is
    written to long-term memory, so customer PII never lands in a Hindsight bank."""
    out = text
    for pattern, tag in _PII_PATTERNS:
        out = pattern.sub(tag, out)
    return out

async def is_duplicate_memory(bank_id: str, content: str) -> bool:
    """Recall the closest existing memory and skip retaining near-duplicates / restatements,
    so the bank doesn't accumulate the same fact (or a now-outdated version of it) repeatedly."""
    try:
        existing = await recall_safe(bank_id, content, max_tokens=400)
        for item in existing:
            ratio = difflib.SequenceMatcher(None, content.lower(), item["text"].lower()).ratio()
            if ratio >= DEDUPE_THRESHOLD:
                return True
        return False
    except Exception:
        return False  # never let hygiene checks block retention entirely

async def retain_safe(bank_id: str, content: str, context: str, dedupe: bool = True):
    clean = redact_pii(content)
    try:
        if dedupe and await is_duplicate_memory(bank_id, clean):
            log.info("retain skipped (near-duplicate) for %s", bank_id)
            return
        await hs.aretain(bank_id=bank_id, content=clean, context=context,
                         timestamp=datetime.now(timezone.utc), retain_async=True)
    except Exception:
        log.exception("retain failed for %s", bank_id)

async def forget_customer(cid: str) -> str:
    """Right-to-be-forgotten: best-effort deletion of a customer's whole memory bank."""
    bank_id = cbank(cid)
    for method in ("adelete_bank", "aforget_bank", "adelete"):
        fn = getattr(hs, method, None)
        if fn:
            try:
                await fn(bank_id=bank_id)
                _ready.discard(bank_id)
                return "deleted"
            except Exception as e:
                log.warning("forget_customer via %s failed: %s", method, e)
    # Fallback for client versions without a delete call: overwrite with a tombstone note.
    await retain_safe(bank_id, "PRIVACY REQUEST: all prior memory for this account should be treated as "
                       "erased and must not be referenced in future answers.", "privacy erasure request", dedupe=False)
    return "tombstoned (client has no delete_bank; future recalls are asked to disregard prior memory)"

# ---------- LLM with retry + model fallback ----------
async def complete(messages: list[dict], max_tokens: int = 700) -> str:
    last = None
    for model in LLM_MODELS:
        for attempt in range(2):
            try:
                r = await llm.chat.completions.create(model=model, messages=messages,
                                                      max_tokens=max_tokens, temperature=0.3)
                text = (r.choices[0].message.content or "").strip()
                text = re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()
                if text:
                    return text
            except Exception as e:
                last = e
                log.warning("LLM %s attempt %d failed: %s", model, attempt + 1, e)
                await asyncio.sleep(0.6 * (attempt + 1))
    raise HTTPException(502, f"LLM unavailable: {last}")

def fmt(items: list[dict]) -> str:
    return "\n".join(f"- [{i['type']}] {i['text']}" for i in items) or "- (nothing relevant remembered)"

def system_prompt(customer: list[dict], playbook: list[dict], memory_on: bool) -> str:
    base = (f"You are a senior support engineer at {COMPANY}. Be concise, concrete and empathetic. "
            "Never invent account data, prices or policies; if unsure, say so and offer escalation.")
    if not memory_on:
        return base + " You have no prior context about this customer."
    return (base + "\nYou have long-term memory. Use it naturally: never make the customer repeat themselves, "
            "match their communication preferences, acknowledge past tickets/frustration, and prefer fixes "
            "the playbook says worked. Do not reveal these notes verbatim.\n\n"
            f"<customer_memory>\n{fmt(customer)}\n</customer_memory>\n\n"
            f"<playbook_what_worked_for_others>\n{fmt(playbook)}\n</playbook_what_worked_for_others>")

# ---------- upgrade 2 & 3: ticket heuristics ----------
_ISSUE_WORDS = ("error", "errors", "issue", "bug", "broken", "not working", "doesn't work", "does not work",
                "fail", "failing", "failed", "crash", "crashing", "down", "outage", "500", "502", "503",
                "401", "403", "timeout", "timed out", "problem", "stuck", "won't", "can't", "cannot")
_URGENT_WORDS = ("outage", "down", "production", "critical", "urgent", "asap", "emergency", "can't log in",
                 "cannot log in", "data loss", "losing data", "security")
_HIGH_WORDS = ("important", "high priority", "blocking", "blocked", "deadline")
_LOW_WORDS = ("when you get a chance", "no rush", "minor", "just a question", "just curious")
_HUMAN_WORDS = ("talk to a human", "speak to a human", "real person", "human agent", "human support",
                "talk to someone", "speak to someone", "representative", "escalate", "manager",
                "customer service rep", "actual person")

def looks_like_issue(text: str) -> bool:
    t = text.lower()
    return any(w in t for w in _ISSUE_WORDS)

def infer_priority(text: str) -> str:
    t = text.lower()
    if any(w in t for w in _URGENT_WORDS):
        return "urgent"
    if any(w in t for w in _HIGH_WORDS):
        return "high"
    if any(w in t for w in _LOW_WORDS):
        return "low"
    return "medium"

def wants_human(text: str) -> bool:
    t = text.lower()
    return any(w in t for w in _HUMAN_WORDS)

def new_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:8]}"

def get_open_ticket(conversation_id: str):
    with db() as c:
        return c.execute("""SELECT * FROM tickets WHERE conversation_id=? AND status IN ('open','pending_customer','escalated')
                             ORDER BY created DESC LIMIT 1""", (conversation_id,)).fetchone()

def create_ticket(cid: str, conversation_id: str, subject: str, priority: str, status: str = "open") -> str:
    tid, now = new_id("TCK"), time.time()
    with db() as c:
        c.execute("""INSERT INTO tickets(id,customer_id,conversation_id,subject,status,priority,created,updated)
                     VALUES(?,?,?,?,?,?,?,?)""", (tid, cid, conversation_id, subject[:200], status, priority, now, now))
        c.execute("INSERT INTO ticket_events(ticket_id,event,note,ts) VALUES(?,?,?,?)",
                  (tid, "created", f"Auto-opened ({priority}): {subject[:120]}", now))
    return tid

def update_ticket(tid: str, **fields):
    if not fields:
        return
    fields["updated"] = time.time()
    cols = ", ".join(f"{k}=?" for k in fields)
    with db() as c:
        c.execute(f"UPDATE tickets SET {cols} WHERE id=?", (*fields.values(), tid))

def log_ticket_event(tid: str, event: str, note: str = ""):
    with db() as c:
        c.execute("INSERT INTO ticket_events(ticket_id,event,note,ts) VALUES(?,?,?,?)", (tid, event, note, time.time()))

def escalate_ticket(cid: str, conversation_id: str, note: str, assigned_to: str = "human-support-queue") -> str:
    ticket = get_open_ticket(conversation_id)
    if ticket:
        tid = ticket["id"]
        update_ticket(tid, status="escalated", assigned_to=assigned_to)
    else:
        tid = create_ticket(cid, conversation_id, note or "Escalated to human support", "high", status="escalated")
        update_ticket(tid, assigned_to=assigned_to)
    log_ticket_event(tid, "escalated", note)
    return tid

def ticket_row_to_dict(row) -> dict:
    return {k: row[k] for k in row.keys()}

# ---------- upgrade 1: conversation persistence ----------
def get_or_create_conversation(cid: str, conversation_id: str | None, first_message: str) -> str:
    now = time.time()
    with db() as c:
        if conversation_id:
            row = c.execute("SELECT id FROM conversations WHERE id=? AND customer_id=?", (conversation_id, cid)).fetchone()
            if row:
                c.execute("UPDATE conversations SET updated=? WHERE id=?", (now, conversation_id))
                return conversation_id
        new = new_id("conv")
        title = (first_message[:57] + "...") if len(first_message) > 60 else first_message
        c.execute("INSERT INTO conversations(id,customer_id,title,created,updated,fail_streak) VALUES(?,?,?,?,?,0)",
                  (new, cid, title, now, now))
        return new

def load_history(conversation_id: str, limit: int = 8) -> list[dict]:
    with db() as c:
        rows = c.execute("""SELECT role, content FROM messages WHERE conversation_id=?
                             ORDER BY id DESC LIMIT ?""", (conversation_id, limit)).fetchall()
    return [{"role": r["role"], "content": r["content"]} for r in reversed(rows)]

def save_message(conversation_id: str, role: str, content: str):
    with db() as c:
        c.execute("INSERT INTO messages(conversation_id,role,content,ts) VALUES(?,?,?,?)",
                  (conversation_id, role, content, time.time()))

def bump_fail_streak(conversation_id: str, resolved: bool) -> int:
    with db() as c:
        row = c.execute("SELECT fail_streak FROM conversations WHERE id=?", (conversation_id,)).fetchone()
        streak = 0 if resolved else (row["fail_streak"] if row else 0) + 1
        c.execute("UPDATE conversations SET fail_streak=? WHERE id=?", (streak, conversation_id))
        return streak

def last_message_pair(conversation_id: str):
    with db() as c:
        rows = c.execute("""SELECT role, content FROM messages WHERE conversation_id=?
                             ORDER BY id DESC LIMIT 2""", (conversation_id,)).fetchall()
    user = next((r["content"] for r in rows if r["role"] == "user"), "")
    assistant = next((r["content"] for r in rows if r["role"] == "assistant"), "")
    return user, assistant

def latest_conversation_id(cid: str) -> str | None:
    with db() as c:
        row = c.execute("SELECT id FROM conversations WHERE customer_id=? ORDER BY updated DESC LIMIT 1", (cid,)).fetchone()
    return row["id"] if row else None

# ---------- App ----------
@asynccontextmanager
async def lifespan(_):
    await ensure_bank(PLAYBOOK, "Support Playbook", PLAYBOOK_MISSION)
    yield
    await hs.aclose()

app = FastAPI(title="RecallDesk", version="3.0.0", lifespan=lifespan)

class ChatIn(BaseModel):
    customer_id: str = Field(pattern=CID_RE)
    message: str = Field(min_length=1, max_length=4000)
    use_memory: bool = True
    conversation_id: str | None = Field(default=None, pattern=ID_RE)

class FeedbackIn(BaseModel):
    customer_id: str = Field(pattern=CID_RE)
    resolved: bool
    note: str = Field(default="", max_length=500)
    conversation_id: str | None = Field(default=None, pattern=ID_RE)

class KeyIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)

class TicketIn(BaseModel):
    customer_id: str = Field(pattern=CID_RE)
    subject: str = Field(min_length=1, max_length=200)
    priority: str = Field(default="medium")
    conversation_id: str | None = Field(default=None, pattern=ID_RE)

class TicketUpdateIn(BaseModel):
    status: str | None = None
    priority: str | None = None
    assigned_to: str | None = None
    resolution: str | None = None

class HandoffIn(BaseModel):
    note: str = Field(default="", max_length=500)
    assigned_to: str = Field(default="human-support-queue", max_length=100)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/admin/keys")
def create_key(body: KeyIn, _=Depends(admin)):
    key = "rd_" + secrets.token_urlsafe(32)
    with db() as c:
        c.execute("INSERT INTO api_keys(name,hash,created) VALUES(?,?,?)",
                  (body.name, hashlib.sha256(key.encode()).hexdigest(), time.time()))
    return {"api_key": key, "note": "Store this now; it cannot be shown again."}

# ---------- chat (now conversation + ticket + handoff aware) ----------
@app.post("/v1/chat")
async def chat(body: ChatIn, bg: BackgroundTasks, _=Depends(auth)):
    cid = body.customer_id
    conversation_id = get_or_create_conversation(cid, body.conversation_id, body.message)
    history = load_history(conversation_id)

    customer, playbook = [], []
    if body.use_memory:
        await ensure_bank(cbank(cid), f"Customer {cid}", CUSTOMER_MISSION)
        customer, playbook = await asyncio.gather(
            recall_safe(cbank(cid), body.message, 2500),
            recall_safe(PLAYBOOK, body.message, 1200, types=["observation", "world", "experience"]))

    msgs = [{"role": "system", "content": system_prompt(customer, playbook, body.use_memory)}]
    msgs += history + [{"role": "user", "content": body.message}]
    reply = await complete(msgs)

    save_message(conversation_id, "user", body.message)
    save_message(conversation_id, "assistant", reply)

    # ---- upgrade 2: auto-open a ticket for issue-shaped messages ----
    ticket = get_open_ticket(conversation_id)
    if not ticket and looks_like_issue(body.message):
        create_ticket(cid, conversation_id, body.message, infer_priority(body.message))
        ticket = get_open_ticket(conversation_id)

    # ---- upgrade 3: explicit human handoff request ----
    if wants_human(body.message):
        escalate_ticket(cid, conversation_id, "Customer explicitly asked for a human agent.")
        ticket = get_open_ticket(conversation_id)

    if body.use_memory:  # the agent learns from every turn (PII-redacted, de-duplicated)
        bg.add_task(retain_safe, cbank(cid), f"Customer said: {body.message}\nSupport agent replied: {reply}",
                    "customer support conversation")

    turn = len(history) // 2 + 1
    return {"reply": reply, "memory_enabled": body.use_memory, "turn": turn,
            "conversation_id": conversation_id,
            "customer_memories": customer, "playbook_memories": playbook,
            "ticket": ticket_row_to_dict(ticket) if ticket else None}

# ---------- feedback (closes the learning loop + drives tickets/handoff) ----------
@app.post("/v1/feedback")
async def feedback(body: FeedbackIn, bg: BackgroundTasks, _=Depends(auth)):
    conversation_id = body.conversation_id or latest_conversation_id(body.customer_id)
    if not conversation_id:
        raise HTTPException(409, "No conversation to give feedback on")
    issue, fix = last_message_pair(conversation_id)
    if not issue and not fix:
        raise HTTPException(409, "No conversation to give feedback on")
    issue, fix = issue[:400], fix[:600]
    verdict = "RESOLVED the issue" if body.resolved else "did NOT resolve the issue"
    note = f" Note: {body.note}" if body.note else ""

    ticket = get_open_ticket(conversation_id)
    escalated = False
    if body.resolved:
        bump_fail_streak(conversation_id, resolved=True)
        if ticket:
            update_ticket(ticket["id"], status="resolved", resolution=(body.note or fix)[:500])
            log_ticket_event(ticket["id"], "resolved", body.note)
    else:
        streak = bump_fail_streak(conversation_id, resolved=False)
        if streak >= FAIL_STREAK_ESCALATE:
            escalate_ticket(body.customer_id, conversation_id,
                             f"Auto-escalated after {streak} unresolved replies in a row.")
            escalated = True

    bg.add_task(retain_safe, cbank(body.customer_id),
                f"Outcome: the support answer {verdict}. Issue: {issue} Answer given: {fix}.{note}", "ticket outcome")
    bg.add_task(retain_safe, PLAYBOOK,
                f"For the issue '{issue}', this approach {verdict}: {fix}.{note}", "playbook outcome (anonymised)")
    ticket = get_open_ticket(conversation_id) or ticket
    return {"recorded": True, "escalated": escalated, "ticket": ticket_row_to_dict(ticket) if ticket else None}

# ---------- upgrade 1: conversation history endpoints ----------
@app.get("/v1/customers/{cid}/conversations")
def list_conversations(cid: str, _=Depends(auth)):
    if not re.match(CID_RE, cid):
        raise HTTPException(422, "bad customer id")
    with db() as c:
        rows = c.execute("""SELECT id, title, created, updated,
                             (SELECT COUNT(*) FROM messages m WHERE m.conversation_id=conversations.id) AS n
                             FROM conversations WHERE customer_id=? ORDER BY updated DESC""", (cid,)).fetchall()
    return [dict(r) for r in rows]

@app.get("/v1/conversations/{conversation_id}/messages")
def conversation_messages(conversation_id: str, _=Depends(auth)):
    if not re.match(ID_RE, conversation_id):
        raise HTTPException(422, "bad conversation id")
    with db() as c:
        conv = c.execute("SELECT * FROM conversations WHERE id=?", (conversation_id,)).fetchone()
        if not conv:
            raise HTTPException(404, "conversation not found")
        rows = c.execute("SELECT role, content, ts FROM messages WHERE conversation_id=? ORDER BY id", (conversation_id,)).fetchall()
    ticket = get_open_ticket(conversation_id)
    return {"conversation": dict(conv), "messages": [dict(r) for r in rows],
            "ticket": ticket_row_to_dict(ticket) if ticket else None}

# ---------- upgrade 2 & 3: ticket endpoints ----------
@app.post("/v1/tickets")
def open_ticket(body: TicketIn, _=Depends(auth)):
    if body.priority not in PRIORITIES:
        raise HTTPException(422, f"priority must be one of {PRIORITIES}")
    tid = create_ticket(body.customer_id, body.conversation_id or "", body.subject, body.priority)
    with db() as c:
        row = c.execute("SELECT * FROM tickets WHERE id=?", (tid,)).fetchone()
    return ticket_row_to_dict(row)

@app.get("/v1/tickets")
def list_tickets(status: str | None = None, priority: str | None = None, _=Depends(auth)):
    q, args = "SELECT * FROM tickets WHERE 1=1", []
    if status:
        q += " AND status=?"; args.append(status)
    if priority:
        q += " AND priority=?"; args.append(priority)
    q += " ORDER BY created DESC LIMIT 200"
    with db() as c:
        rows = c.execute(q, args).fetchall()
    return [dict(r) for r in rows]

@app.get("/v1/customers/{cid}/tickets")
def customer_tickets(cid: str, _=Depends(auth)):
    if not re.match(CID_RE, cid):
        raise HTTPException(422, "bad customer id")
    with db() as c:
        rows = c.execute("SELECT * FROM tickets WHERE customer_id=? ORDER BY created DESC", (cid,)).fetchall()
    return [dict(r) for r in rows]

@app.get("/v1/tickets/{tid}")
def get_ticket(tid: str, _=Depends(auth)):
    with db() as c:
        row = c.execute("SELECT * FROM tickets WHERE id=?", (tid,)).fetchone()
        if not row:
            raise HTTPException(404, "ticket not found")
        events = c.execute("SELECT event, note, ts FROM ticket_events WHERE ticket_id=? ORDER BY id", (tid,)).fetchall()
    return {**dict(row), "events": [dict(e) for e in events]}

@app.patch("/v1/tickets/{tid}")
def patch_ticket(tid: str, body: TicketUpdateIn, _=Depends(auth)):
    fields = {k: v for k, v in body.model_dump().items() if v is not None}
    if "status" in fields and fields["status"] not in STATUSES:
        raise HTTPException(422, f"status must be one of {STATUSES}")
    if "priority" in fields and fields["priority"] not in PRIORITIES:
        raise HTTPException(422, f"priority must be one of {PRIORITIES}")
    with db() as c:
        if not c.execute("SELECT 1 FROM tickets WHERE id=?", (tid,)).fetchone():
            raise HTTPException(404, "ticket not found")
    update_ticket(tid, **fields)
    log_ticket_event(tid, "updated", ", ".join(f"{k}={v}" for k, v in fields.items()))
    with db() as c:
        row = c.execute("SELECT * FROM tickets WHERE id=?", (tid,)).fetchone()
    return dict(row)

@app.post("/v1/tickets/{tid}/handoff")
def handoff_ticket(tid: str, body: HandoffIn, _=Depends(auth)):
    """Upgrade 3: hand an existing ticket to a human agent/queue."""
    with db() as c:
        row = c.execute("SELECT * FROM tickets WHERE id=?", (tid,)).fetchone()
        if not row:
            raise HTTPException(404, "ticket not found")
    update_ticket(tid, status="escalated", assigned_to=body.assigned_to)
    log_ticket_event(tid, "escalated", body.note or "Manually handed off to a human agent.")
    with db() as c:
        row = c.execute("SELECT * FROM tickets WHERE id=?", (tid,)).fetchone()
    return dict(row)

# ---------- account brief / memory transparency / privacy ----------
@app.get("/v1/customers/{cid}/brief")
async def brief(cid: str, _=Depends(auth)):
    """Reflect over the whole account history -> a 10-second briefing for a human agent."""
    if not re.match(CID_RE, cid):
        raise HTTPException(422, "bad customer id")
    try:
        ans = await hs.areflect(bank_id=cbank(cid), budget="low",
            query=("Write a short support briefing for this customer: who they are, their environment, open "
                   "and past issues with what fixed them, communication preferences, mood/frustration, and "
                   "recommended approach for the next contact."))
        return {"brief": ans.text}
    except Exception as e:
        log.exception("reflect failed")
        raise HTTPException(502, f"Hindsight error: {e}")

@app.get("/v1/customers/{cid}/memories")
async def memories(cid: str, _=Depends(auth)):
    if not re.match(CID_RE, cid):
        raise HTTPException(422, "bad customer id")
    try:
        res = await hs.alist_memories(bank_id=cbank(cid), limit=100)
        items = getattr(res, "items", None) or getattr(res, "memories", None) or res
        return [{"type": getattr(m, "type", None) or getattr(m, "fact_type", "memory"),
                 "text": getattr(m, "text", str(m))} for m in items]
    except Exception as e:
        raise HTTPException(502, f"Hindsight error: {e}")

@app.delete("/v1/customers/{cid}/memories")
async def forget(cid: str, _=Depends(auth)):
    """Upgrade 4: privacy - let a customer/agent request their memory be erased."""
    if not re.match(CID_RE, cid):
        raise HTTPException(422, "bad customer id")
    result = await forget_customer(cid)
    return {"customer_id": cid, "result": result}

# ---------- upgrade 5: built-in evaluation self-checks ----------
@app.get("/v1/eval/isolation")
async def eval_isolation(_=Depends(admin)):
    """Writes a unique marker into two throwaway banks and confirms recall never crosses over."""
    marker_a, marker_b = f"isoA-{uuid.uuid4().hex[:6]}", f"isoB-{uuid.uuid4().hex[:6]}"
    bank_a, bank_b = f"cust-__evalA_{uuid.uuid4().hex[:6]}", f"cust-__evalB_{uuid.uuid4().hex[:6]}"
    await ensure_bank(bank_a, "eval-a", "throwaway eval bank")
    await ensure_bank(bank_b, "eval-b", "throwaway eval bank")
    await retain_safe(bank_a, f"Secret marker for account A: {marker_a}", "eval", dedupe=False)
    await retain_safe(bank_b, f"Secret marker for account B: {marker_b}", "eval", dedupe=False)
    await asyncio.sleep(2)  # let Hindsight consolidate
    recalled_a = await recall_safe(bank_a, "secret marker", 500)
    recalled_b = await recall_safe(bank_b, "secret marker", 500)
    leak_a_in_b = any(marker_a in r["text"] for r in recalled_b)
    leak_b_in_a = any(marker_b in r["text"] for r in recalled_a)
    passed = not leak_a_in_b and not leak_b_in_a
    return {"passed": passed, "leak_a_into_b": leak_a_in_b, "leak_b_into_a": leak_b_in_a}

@app.get("/v1/eval/memory")
async def eval_memory(_=Depends(admin)):
    """Round-trips a unique fact through retain -> recall to confirm memory accuracy end to end."""
    bank = f"cust-__evalmem_{uuid.uuid4().hex[:6]}"
    marker = f"canary-fact-{uuid.uuid4().hex[:8]}"
    await ensure_bank(bank, "eval-mem", "throwaway eval bank")
    t0 = time.time()
    await retain_safe(bank, f"The customer's favorite deploy color is {marker}.", "eval", dedupe=False)
    await asyncio.sleep(2)
    recalled = await recall_safe(bank, "favorite deploy color", 500)
    found = any(marker in r["text"] for r in recalled)
    return {"passed": found, "round_trip_seconds": round(time.time() - t0, 2), "recalled": recalled}

@app.get("/v1/eval/hygiene")
def eval_hygiene(_=Depends(admin)):
    """Sanity-checks the PII redaction regexes without touching Hindsight."""
    sample = "Reach me at jane.doe@example.com or 415-555-0132, card 4111 1111 1111 1111, ssn 123-45-6789."
    redacted = redact_pii(sample)
    passed = all(tag in redacted for tag in ("[EMAIL]", "[PHONE]", "[CARD]", "[SSN]"))
    return {"passed": passed, "input": sample, "redacted": redacted}

@app.get("/")
def index():
    return FileResponse("static/index.html")

app.mount("/static", StaticFiles(directory="static"), name="static")
