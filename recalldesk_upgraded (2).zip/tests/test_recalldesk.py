"""Offline test suite for RecallDesk (upgrade 5: Testing & Evaluation).

Runs with no network, no real Hindsight server and no real LLM: the Hindsight client and the
OpenAI client are monkeypatched with in-memory fakes so `pytest` works anywhere.

Run:  pip install pytest fastapi httpx
      pytest tests/ -v
"""
import os, sys, time, uuid, asyncio, importlib
import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


# ---------- fakes ----------
class FakeRecallResult:
    def __init__(self, text, type_="observation"):
        self.text, self.type = text, type_

class FakeRecallResponse:
    def __init__(self, results):
        self.results = results

class FakeReflectResponse:
    def __init__(self, text):
        self.text = text

class FakeHindsight:
    """In-memory stand-in for hindsight_client.Hindsight, keyed by bank_id so we can also
    assert cross-customer isolation."""
    def __init__(self, *a, **kw):
        self.banks: dict[str, list[str]] = {}

    async def acreate_bank(self, bank_id, name, mission):
        self.banks.setdefault(bank_id, [])

    async def aretain(self, bank_id, content, context, timestamp, retain_async=True):
        self.banks.setdefault(bank_id, []).append(content)

    async def arecall(self, bank_id, query, max_tokens, budget="mid", types=None):
        items = self.banks.get(bank_id, [])
        return FakeRecallResponse([FakeRecallResult(t) for t in items[-5:]])

    async def areflect(self, bank_id, budget, query):
        return FakeReflectResponse("Brief for " + bank_id + ": " + "; ".join(self.banks.get(bank_id, [])))

    async def alist_memories(self, bank_id, limit=100):
        return [type("M", (), {"type": "observation", "text": t}) for t in self.banks.get(bank_id, [])]

    async def aclose(self):
        pass


class FakeChoice:
    def __init__(self, content):
        self.message = type("Msg", (), {"content": content})

class FakeCompletion:
    def __init__(self, content):
        self.choices = [FakeChoice(content)]

class FakeChatCompletions:
    async def create(self, model, messages, max_tokens, temperature):
        return FakeCompletion("This is a canned support reply.")

class FakeChat:
    def __init__(self):
        self.completions = FakeChatCompletions()

class FakeOpenAI:
    def __init__(self, *a, **kw):
        self.chat = FakeChat()


@pytest.fixture()
def app_module(tmp_path, monkeypatch):
    """Import main.py fresh with fakes in place and an isolated on-disk sqlite file."""
    monkeypatch.setenv("DB_PATH", str(tmp_path / "test.db"))
    monkeypatch.setenv("ADMIN_KEY", "test-admin-key")
    monkeypatch.setenv("FAIL_STREAK_ESCALATE", "2")

    import hindsight_client
    monkeypatch.setattr(hindsight_client, "Hindsight", FakeHindsight, raising=False)
    import openai
    monkeypatch.setattr(openai, "AsyncOpenAI", FakeOpenAI, raising=False)

    if "main" in sys.modules:
        del sys.modules["main"]
    import main as m
    return m


@pytest.fixture()
def client(app_module):
    from fastapi.testclient import TestClient
    with TestClient(app_module.app) as c:
        yield c


def make_key(client, name="demo"):
    r = client.post("/admin/keys", json={"name": name}, headers={"X-Admin-Key": "test-admin-key"})
    assert r.status_code == 200
    return r.json()["api_key"]


# ---------- upgrade 4: memory hygiene ----------
def test_redact_pii_strips_all_categories(app_module):
    sample = "Email jane@acme.com, call 415-555-0132, card 4111 1111 1111 1111, ssn 123-45-6789."
    redacted = app_module.redact_pii(sample)
    assert "[EMAIL]" in redacted and "[PHONE]" in redacted and "[CARD]" in redacted and "[SSN]" in redacted
    assert "jane@acme.com" not in redacted


@pytest.mark.asyncio
async def test_dedupe_skips_near_identical_memory(app_module):
    bank = "cust-dedupe-test"
    await app_module.ensure_bank(bank, "t", "t")
    await app_module.retain_safe(bank, "Customer's proxy needs HTTPS_PROXY set and a 30s timeout.", "ctx")
    before = len(app_module.hs.banks[bank])
    await app_module.retain_safe(bank, "Customer's proxy needs HTTPS_PROXY set and a 30-second timeout.", "ctx")
    after = len(app_module.hs.banks[bank])
    assert after == before, "near-duplicate memory should have been skipped"


@pytest.mark.asyncio
async def test_dedupe_keeps_genuinely_new_memory(app_module):
    bank = "cust-dedupe-test-2"
    await app_module.ensure_bank(bank, "t", "t")
    await app_module.retain_safe(bank, "Prefers email over phone.", "ctx")
    await app_module.retain_safe(bank, "Uses Kubernetes on GCP with Node 20 services.", "ctx")
    assert len(app_module.hs.banks[bank]) == 2


# ---------- upgrade 1: conversation history ----------
def test_chat_persists_and_resumes_conversation(client):
    key = make_key(client)
    h = {"X-API-Key": key}
    r1 = client.post("/v1/chat", json={"customer_id": "acme", "message": "Hi there", "use_memory": False}, headers=h)
    assert r1.status_code == 200
    conv_id = r1.json()["conversation_id"]

    r2 = client.post("/v1/chat", json={"customer_id": "acme", "message": "Second message",
                                        "use_memory": False, "conversation_id": conv_id}, headers=h)
    assert r2.json()["conversation_id"] == conv_id

    listing = client.get("/v1/customers/acme/conversations", headers=h).json()
    assert any(c["id"] == conv_id and c["n"] == 4 for c in listing)

    resumed = client.get(f"/v1/conversations/{conv_id}/messages", headers=h).json()
    assert len(resumed["messages"]) == 4
    assert resumed["messages"][0]["content"] == "Hi there"


# ---------- upgrade 2: ticket management ----------
def test_issue_message_autocreates_ticket_with_priority(client):
    key = make_key(client)
    h = {"X-API-Key": key}
    r = client.post("/v1/chat", json={"customer_id": "acme2",
                     "message": "Production is down, webhooks are failing with 500 errors!",
                     "use_memory": False}, headers=h)
    ticket = r.json()["ticket"]
    assert ticket is not None
    assert ticket["priority"] == "urgent"
    assert ticket["status"] == "open"


def test_manual_ticket_and_patch(client):
    key = make_key(client)
    h = {"X-API-Key": key}
    r = client.post("/v1/tickets", json={"customer_id": "acme3", "subject": "Billing question", "priority": "low"}, headers=h)
    tid = r.json()["id"]
    p = client.patch(f"/v1/tickets/{tid}", json={"status": "resolved", "resolution": "Explained invoice."}, headers=h)
    assert p.json()["status"] == "resolved"


# ---------- upgrade 3: human handoff ----------
def test_repeated_negative_feedback_autoescalates(client):
    key = make_key(client)
    h = {"X-API-Key": key}
    r = client.post("/v1/chat", json={"customer_id": "acme4", "message": "My integration is broken",
                                       "use_memory": False}, headers=h)
    conv_id = r.json()["conversation_id"]
    client.post("/v1/feedback", json={"customer_id": "acme4", "resolved": False, "conversation_id": conv_id}, headers=h)
    r2 = client.post("/v1/feedback", json={"customer_id": "acme4", "resolved": False, "conversation_id": conv_id}, headers=h)
    assert r2.json()["escalated"] is True
    assert r2.json()["ticket"]["status"] == "escalated"


def test_explicit_human_request_escalates_immediately(client):
    key = make_key(client)
    h = {"X-API-Key": key}
    r = client.post("/v1/chat", json={"customer_id": "acme5",
                     "message": "This isn't working, please let me talk to a human agent",
                     "use_memory": False}, headers=h)
    assert r.json()["ticket"]["status"] == "escalated"


# ---------- upgrade 5: data isolation across customers ----------
@pytest.mark.asyncio
async def test_customer_banks_are_isolated(app_module):
    bank_a, bank_b = app_module.cbank("cust-a"), app_module.cbank("cust-b")
    await app_module.ensure_bank(bank_a, "a", "a")
    await app_module.ensure_bank(bank_b, "b", "b")
    await app_module.retain_safe(bank_a, "Secret detail only for customer A: rotation-code-XYZ", "ctx", dedupe=False)
    recalled_b = await app_module.recall_safe(bank_b, "rotation code", 500)
    assert not any("XYZ" in r["text"] for r in recalled_b)


def test_eval_endpoints_are_admin_only(client):
    assert client.get("/v1/eval/hygiene").status_code == 403
    assert client.get("/v1/eval/hygiene", headers={"X-Admin-Key": "test-admin-key"}).status_code == 200
