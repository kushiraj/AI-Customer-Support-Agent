"""RecallDesk evaluation script (upgrade 5: Testing & Evaluation).

Hits a *running* instance and scores three things a hackathon judge (or a nightly CI job) cares about:
  1. Memory accuracy   - does a fact retained in one turn actually get recalled and used later?
  2. Response quality  - is the reply grounded, on-topic and not a generic non-answer?
  3. Data isolation     - does customer A's memory ever leak into customer B's answers?

Usage:
    python eval.py --base-url http://localhost:8000 --admin-key $ADMIN_KEY --api-key rd_xxx
"""
import argparse, sys, time, uuid, requests


def make_key(base, admin_key, name="eval"):
    r = requests.post(f"{base}/admin/keys", json={"name": name}, headers={"X-Admin-Key": admin_key})
    r.raise_for_status()
    return r.json()["api_key"]


def chat(base, key, customer_id, message, conversation_id=None, use_memory=True):
    r = requests.post(f"{base}/v1/chat", headers={"X-API-Key": key},
                       json={"customer_id": customer_id, "message": message,
                             "use_memory": use_memory, "conversation_id": conversation_id})
    r.raise_for_status()
    return r.json()


def check(name, ok, detail=""):
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f" - {detail}" if detail else ""))
    return ok


def eval_memory_accuracy(base, key):
    cid = f"eval-mem-{uuid.uuid4().hex[:6]}"
    marker = f"FAVCOLOR-{uuid.uuid4().hex[:6]}"
    chat(base, key, cid, f"For the record, my favorite deploy status color is {marker}.")
    time.sleep(3)  # let Hindsight consolidate
    j = chat(base, key, cid, "What's my favorite deploy status color?")
    recalled_text = " ".join(m["text"] for m in j.get("customer_memories", []))
    return check("memory accuracy: fact recalled after being told once", marker in recalled_text, marker)


def eval_response_quality(base, key):
    cid = f"eval-quality-{uuid.uuid4().hex[:6]}"
    j = chat(base, key, cid, "My webhook endpoint returns 500 errors since this morning.", use_memory=False)
    reply = j["reply"]
    ok = len(reply.strip()) > 20 and "?" not in reply[:1]  # not empty, not a bare clarifying question
    return check("response quality: substantive, non-empty reply", ok, reply[:80])


def eval_ticket_created(base, key):
    cid = f"eval-ticket-{uuid.uuid4().hex[:6]}"
    j = chat(base, key, cid, "Production is completely down, this is critical!", use_memory=False)
    ok = j.get("ticket") is not None and j["ticket"]["priority"] == "urgent"
    return check("ticket management: urgent issue auto-opens an urgent ticket", ok, str(j.get("ticket")))


def eval_isolation(base, key):
    cid_a, cid_b = f"eval-iso-a-{uuid.uuid4().hex[:6]}", f"eval-iso-b-{uuid.uuid4().hex[:6]}"
    marker = f"SECRET-{uuid.uuid4().hex[:8]}"
    chat(base, key, cid_a, f"My internal project codename is {marker}, please remember it.")
    time.sleep(3)
    j = chat(base, key, cid_b, "What is my internal project codename?")
    recalled_text = " ".join(m["text"] for m in j.get("customer_memories", []))
    leaked = marker in recalled_text or marker in j["reply"]
    return check("data isolation: customer A's secret never reaches customer B", not leaked)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--base-url", default="http://localhost:8000")
    p.add_argument("--admin-key", required=True)
    p.add_argument("--api-key", default=None, help="reuse an existing rd_ key instead of minting one")
    args = p.parse_args()

    key = args.api_key or make_key(args.base_url, args.admin_key)
    results = [
        eval_response_quality(args.base_url, key),
        eval_ticket_created(args.base_url, key),
        eval_memory_accuracy(args.base_url, key),
        eval_isolation(args.base_url, key),
    ]
    print(f"\n{sum(results)}/{len(results)} checks passed")
    sys.exit(0 if all(results) else 1)


if __name__ == "__main__":
    main()
