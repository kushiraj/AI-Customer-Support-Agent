"""Seed realistic customer histories into Hindsight so the demo starts with weeks of context.
Usage: python seed.py   (needs HINDSIGHT_URL / HINDSIGHT_API_KEY env vars)"""
import os
from datetime import datetime, timedelta, timezone
from hindsight_client import Hindsight

hs = Hindsight(base_url=os.getenv("HINDSIGHT_URL", "http://localhost:8888"), api_key=os.getenv("HINDSIGHT_API_KEY") or None, timeout=120.0)
now = datetime.now(timezone.utc)
def ago(d): return now - timedelta(days=d)

CUSTOMERS = {
 "northwind-logistics": [
  (42, "Priya Nair (Head of Platform, Northwind Logistics) onboarded on the Enterprise plan. Stack: Node 18 services on Kubernetes behind a corporate HTTP proxy. She prefers short, direct answers with exact commands, no small talk."),
  (30, "Ticket #4812: webhooks returned 401 after Priya rotated API keys. Root cause: the webhook signing secret is separate from the API key and must be re-issued. Re-issuing the signing secret fixed it. Priya was frustrated: it was the second outage in a month."),
  (18, "Ticket #4977: SDK timeouts from Northwind's proxy. Fix that worked: set HTTPS_PROXY and raise SDK timeout to 30s. Priya said she is tired of re-explaining their proxy setup every time."),
  (6,  "Ticket #5120: duplicate webhook deliveries. Fix: make the handler idempotent using the event id header. Priya confirmed resolved and thanked the team. Mood: calmer, but still escalation-sensitive."),
 ],
 "brightpath-health": [
  (25, "Daniel Ortiz (IT Manager, BrightPath Health) is on the Growth plan. Healthcare customer: HIPAA-sensitive, wants email follow-ups with written summaries and never phone calls."),
  (14, "Ticket #5033: SAML SSO login loop. Cause: clock skew on the IdP. Fix: enable NTP sync and set assertion clock tolerance to 120s. Resolved."),
  (3,  "Daniel asked whether audit logs can be exported for a compliance review next month. Told: CSV export is available on Growth. Daniel wants a reminder a week before the review."),
 ],
}
PLAYBOOK = [
 "For 401 errors on webhooks after rotating API keys, re-issuing the webhook signing secret resolved the issue in most cases.",
 "For SDK timeouts behind a corporate proxy, setting HTTPS_PROXY and raising the SDK timeout to 30s resolved the issue.",
 "For SAML SSO login loops, fixing IdP clock skew (NTP, 120s tolerance) resolved the issue. Restarting the IdP did NOT help.",
 "For duplicate webhook deliveries, making the handler idempotent using the event id header resolved the issue.",
]

for cid, events in CUSTOMERS.items():
    bank = f"cust-{cid}"
    try:
        hs.create_bank(bank_id=bank, name=f"Customer {cid}", mission="Support memory for one customer account: people, environment, tickets, preferences, frustration level.")
    except Exception as e:
        print("bank exists?", e)
    for days, text in events:
        hs.retain(bank_id=bank, content=text, context="support history", timestamp=ago(days))
    print("seeded", cid)
try:
    hs.create_bank(bank_id="recalldesk-playbook", name="Support Playbook", mission="Which fixes worked for which issues.")
except Exception as e:
    print("playbook exists?", e)
for t in PLAYBOOK:
    hs.retain(bank_id="recalldesk-playbook", content=t, context="playbook", timestamp=ago(10))
print("done. Wait ~30s for consolidation, then try customer 'northwind-logistics'.")
