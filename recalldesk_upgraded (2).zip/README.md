# RecallDesk: the fix one customer finds becomes every customer's fix (Hindsight hackathon)

**The part most memory-powered support demos skip:** remembering *one* customer's history is the easy half.
The hard, valuable half is turning what worked for customer A into a fix customer B gets automatically —
without anyone writing a runbook. That's what RecallDesk's shared **playbook bank** does: every resolved
ticket, from any customer, becomes something the agent can recall the next time a *different* customer
hits a similar issue. Two banks, two jobs:

- `cust-<id>` — one private bank per account: their people, stack, ticket history, mood, preferences.
- `recalldesk-playbook` — one bank shared across every account: which fixes actually worked, and which didn't.

**Problem:** support customers hate repeating their story, agents re-read old tickets before every reply,
and the fix a senior engineer found for customer A never reaches the junior agent helping customer B with
the same bug three weeks later. **Solution:** [Hindsight](https://hindsight.vectorize.io) as the memory
layer for both. Toggle **Memory OFF/ON** in the UI to see generic vs personalised answers side by side.

## Workflow

    Customer → AI Chat → Recall Memory (account + shared playbook) → Generate Answer
             → Create Ticket if Needed → Human Support → Save Resolution → Playbook grows for everyone

## The 5 upgrades in this version

| # | Upgrade | What was added |
|---|---|---|
| 1 | **Conversation History** | Every chat is saved to SQLite (`conversations` + `messages` tables). `POST /v1/chat` returns a `conversation_id`; pass it back in to continue a chat, or omit it to start a new one. `GET /v1/customers/{cid}/conversations` lists past chats and `GET /v1/conversations/{id}/messages` resumes one. The UI has a left-hand conversation list and a **+ New chat** button. |
| 2 | **Ticket Management** | A `tickets` table tracks `status` (`open` → `pending_customer` / `escalated` → `resolved`/`closed`) and `priority` (`low`/`medium`/`high`/`urgent`). A ticket is auto-opened the moment a message looks like an issue (error/broken/down/etc.), with priority inferred from keywords (e.g. "production down" → `urgent`). Manage tickets via `POST /v1/tickets`, `GET/PATCH /v1/tickets/{id}`, `GET /v1/customers/{cid}/tickets`, `GET /v1/tickets?status=&priority=`. |
| 3 | **Human Handoff** | `POST /v1/tickets/{id}/handoff` transfers a ticket to a human queue (`assigned_to`). It also fires automatically: if the customer explicitly asks for a human ("talk to a human", "escalate", "manager"...), or after 2 unresolved `/v1/feedback` calls in a row (`FAIL_STREAK_ESCALATE`). The UI shows an **Escalate to human** button next to the live ticket status. |
| 4 | **Better Memory** | Before anything is written to a Hindsight bank: (a) `redact_pii()` strips emails, phone numbers, card-like numbers and SSNs so customer PII never enters long-term memory; (b) `is_duplicate_memory()` recalls the closest existing memory and skips the write if it's a near-restatement (`DEDUPE_THRESHOLD`, default 0.82 similarity) so the bank doesn't fill up with the same fact over and over; (c) `DELETE /v1/customers/{cid}/memories` is a right-to-be-forgotten endpoint (a **Forget me** button in the UI) that deletes the customer's bank, or writes a tombstone note if the installed `hindsight-client` version has no delete call. |
| 5 | **Testing & Evaluation** | `tests/test_recalldesk.py` is an offline pytest suite (Hindsight + the LLM are faked, no network needed) covering PII redaction, de-duplication, conversation persistence, ticket auto-creation/priority, auto-escalation, and cross-customer isolation. `eval.py` is a scripted check against a *live* instance for memory-accuracy round-trips, response quality, ticket creation and isolation. Built-in self-checks are also exposed as endpoints: `GET /v1/eval/isolation`, `GET /v1/eval/memory`, `GET /v1/eval/hygiene` (all admin-key protected). |

## How Hindsight is used
| Hindsight call | Where | Purpose |
|---|---|---|
| `create_bank` | `ensure_bank` | One bank per customer (`cust-<id>`) plus a shared `recalldesk-playbook` bank, each with a mission |
| `recall` | `POST /v1/chat`, dedupe check, eval endpoints | Before every reply: customer history + what worked for others (right-hand panel shows exactly what was recalled) |
| `retain` | after each turn, `POST /v1/feedback` | Stores each exchange and ticket outcomes (PII-redacted, de-duplicated); resolved fixes are also written (anonymised) to the playbook, so **the agent improves across customers** |
| `reflect` | `GET /v1/customers/{id}/brief` | 10-second account briefing for a human agent |
| `list_memories` | `GET /v1/customers/{id}/memories` | Transparency / audit view |
| delete/forget | `DELETE /v1/customers/{id}/memories` | Best-effort erase for privacy requests |

## Run
    pip install -r requirements.txt
    cp .env.example .env && export $(grep -v '^#' .env | xargs)   # Hindsight Cloud key + Groq key
    python seed.py                                                # 2 customers with weeks of realistic history
    uvicorn main:app --port 8000
    curl -X POST localhost:8000/admin/keys -H "X-Admin-Key: $ADMIN_KEY" -H "Content-Type: application/json" -d '{"name":"demo"}'
Open http://localhost:8000, paste the `rd_...` key, use customer `northwind-logistics`.

## Testing & evaluation
    pip install -r requirements-dev.txt
    pytest tests/ -v                                              # offline, no Hindsight/LLM/network needed
    python eval.py --base-url http://localhost:8000 --admin-key $ADMIN_KEY   # against a live instance
    curl localhost:8000/v1/eval/isolation -H "X-Admin-Key: $ADMIN_KEY"
    curl localhost:8000/v1/eval/memory    -H "X-Admin-Key: $ADMIN_KEY"
    curl localhost:8000/v1/eval/hygiene   -H "X-Admin-Key: $ADMIN_KEY"

## The memory curve (what to actually show judges)

Don't just flip Memory OFF→ON once — walk the *curve*, since that's what makes memory the star instead of
a feature checkbox:

1. **Interaction 1 (no memory):** customer `northwind-logistics`, Memory **OFF**: "Webhooks are returning
   401 again." → a generic troubleshooting checklist. Note a ticket still auto-opens with an inferred
   priority — ticketing doesn't depend on memory being on.
2. **Interaction 1 (with memory):** flip Memory **ON**, same message → the agent already knows Priya, the
   signing-secret root cause from ticket #4812, her Node 18 + proxy setup, and her preference for short
   answers with no small talk. Click **Resolved** — the fix is written to *both* her account bank and the
   shared playbook.
3. **Interaction "day 1" for a second account:** switch to `brightpath-health`, a customer who has never
   seen this issue before, and describe a similar-shaped problem. The agent proposes the fix that worked
   for Priya — pulled from the shared playbook, not from anything Daniel ever told it. This is the
   moment that proves memory compounds *across* customers, not just within one.
4. **Escalation path:** click **Not resolved** twice in a row on a fresh issue to show the ticket
   **auto-escalate** to the human queue, or type "let me talk to a human" for an immediate handoff. Click
   **Hand off to a human** in the ticket bar to do it manually.
5. **Persistence:** click **New chat**, then reopen the earlier conversation from the left-hand
   **Conversations** rail to show history is saved and resumable, not lost on refresh.
6. **Privacy:** click **Forget customer** to show the right-to-be-forgotten flow, and point out the memory
   counter in the right rail dropping back down.

## Notes
- Endpoints: `/v1/chat`, `/v1/feedback`, `/v1/customers/{id}/brief|memories|conversations|tickets`,
  `/v1/conversations/{id}/messages`, `/v1/tickets`, `/v1/tickets/{id}`, `/v1/tickets/{id}/handoff`,
  `/v1/eval/isolation|memory|hygiene`, `/admin/keys`, `/health`, `/docs`.
- LLM calls retry once per model and fall back to the next model in `LLM_MODELS`; recall/retain failures never break the chat.
- Uses Hindsight Python client v0.10 async methods (`arecall`, `aretain`, `areflect`, `acreate_bank`, `alist_memories`); the forget flow probes for `adelete_bank`/`aforget_bank`/`adelete` and falls back to a tombstone note if none exist on your installed client version.
- New env vars (all optional, sane defaults): `DEDUPE_THRESHOLD` (0.82), `FAIL_STREAK_ESCALATE` (2).
